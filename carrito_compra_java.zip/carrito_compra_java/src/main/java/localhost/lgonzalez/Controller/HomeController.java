package localhost.lgonzalez.Controller;

import localhost.lgonzalez.Model.Producto;
import localhost.lgonzalez.Model.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

@Controller
public class HomeController {
    @Autowired
    private ProductoRepository productoRepository;

    @GetMapping("/")
    public String index(Model model){
        List<Producto> productos = productoRepository.findAll();

        model.AddAtribute("producto", productos);

        return "index";

    }

}
