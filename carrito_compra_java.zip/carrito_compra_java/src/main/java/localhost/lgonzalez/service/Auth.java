package localhost.lgonzalez.service;

public class Auth {
}
