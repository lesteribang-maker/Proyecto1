package localhost.lgonzalez.service;

public class FlashService {
}
