package localhost.lgonzalez.Model;

public class ProductoRepository {
}
