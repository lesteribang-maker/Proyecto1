package localhost.lgonzalez.Model;

public class ShoppingCart {
}
