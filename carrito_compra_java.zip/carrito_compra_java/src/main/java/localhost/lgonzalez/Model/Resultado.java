package localhost.lgonzalez.Model;

public class Resultado {
}
