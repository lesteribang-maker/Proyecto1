package localhost.lgonzalez.Model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table
@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idProducto")
    private Long idProducto;

    @Column(name = "name", length = 255)
    private String nombre;

    @Column(name = "codigo", nullable = false, length = 255)
    private String codigo;

    @Column(name = "imagen", columnDefinition = "TEXT")
    private String imagen;

    @Column(name = "precio")
    private BigDecimal precio;

}
