package localhost.lgonzalez.Model;

public class ShoppingCartRepository {
}
