package localhost.lgonzalez;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarritoCompraJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
